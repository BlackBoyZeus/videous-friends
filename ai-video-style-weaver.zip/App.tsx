
import React, { useState, useCallback, useEffect } from 'react';
import { MediaFile, FineTuneConfig, FineTuneResult, AppPhase, IconProps } from './types';
import { BASE_MODELS, DEFAULT_CONFIG, MAX_CONTENT_VIDEOS, API_KEY_INFO_MESSAGE, getApiKey } from './constants';
import Header from './components/Header';
import Footer from './components/Footer';
import FileUploader from './components/FileUploader';
import MediaPreview from './components/MediaPreview';
import ConfigurationPanel from './components/ConfigurationPanel';
import LoadingSpinner from './components/LoadingSpinner';
import ResultDisplay from './components/ResultDisplay';
import { generateStyleDescription } from './services/geminiService';

// Icons (Heroicons)
const UploadIcon: React.FC<IconProps> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
  </svg>
);

const SparklesIcon: React.FC<IconProps> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L17 13.75M17 8.25L18.25 12M12 18.25L13.75 17M8.25 17L12 18.25" />
  </svg>
);


const App: React.FC = () => {
  const [contentMedia, setContentMedia] = useState<MediaFile[]>([]);
  const [styleMedia, setStyleMedia] = useState<MediaFile | null>(null);
  const [config, setConfig] = useState<FineTuneConfig>(DEFAULT_CONFIG);
  const [appPhase, setAppPhase] = useState<AppPhase>(AppPhase.CONFIGURATION);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<FineTuneResult | null>(null);
  const [apiKeyAvailable, setApiKeyAvailable] = useState<boolean>(false);

  useEffect(() => {
    if (getApiKey()) {
      setApiKeyAvailable(true);
    } else {
      setApiKeyAvailable(false);
      setError(API_KEY_INFO_MESSAGE);
    }
  }, []);

  const handleContentMediaChange = (files: FileList | null) => {
    if (files) {
      const newMediaFiles = Array.from(files)
        .slice(0, MAX_CONTENT_VIDEOS - contentMedia.length)
        .map(file => ({
          id: crypto.randomUUID(),
          file,
          previewUrl: URL.createObjectURL(file),
          name: file.name,
        }));
      setContentMedia(prev => [...prev, ...newMediaFiles]);
    }
  };

  const handleStyleMediaChange = (files: FileList | null) => {
    if (files && files.length > 0) {
      const file = files[0];
      if (styleMedia) {
        URL.revokeObjectURL(styleMedia.previewUrl);
      }
      setStyleMedia({
        id: crypto.randomUUID(),
        file,
        previewUrl: URL.createObjectURL(file),
        name: file.name,
      });
    }
  };

  const removeContentMedia = (id: string) => {
    setContentMedia(prev => {
      const mediaToRemove = prev.find(m => m.id === id);
      if (mediaToRemove) {
        URL.revokeObjectURL(mediaToRemove.previewUrl);
      }
      return prev.filter(m => m.id !== id);
    });
  };

  const removeStyleMedia = () => {
    if (styleMedia) {
      URL.revokeObjectURL(styleMedia.previewUrl);
      setStyleMedia(null);
    }
  };

  const handleConfigChange = useCallback((newConfig: Partial<FineTuneConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  }, []);

  const handleStartFineTuning = async () => {
    if (!apiKeyAvailable) {
      setError(`API Key is not available. ${API_KEY_INFO_MESSAGE}`);
      return;
    }
    if (contentMedia.length === 0 || !styleMedia) {
      setError("Please upload at least one content media and one style media.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);
    setAppPhase(AppPhase.PROCESSING);

    const contentDescription = `Content media: ${contentMedia.map(m => m.name).join(', ')}.`;
    const styleDescription = `Style media: ${styleMedia.name}.`;

    try {
      const geminiDescription = await generateStyleDescription(contentDescription, styleDescription, config);
      setResult({
        configSummary: { ...config },
        geminiDescription,
        timestamp: new Date().toISOString(),
      });
      setAppPhase(AppPhase.RESULTS);
    } catch (e: any) {
      console.error("Fine-tuning simulation error:", e);
      setError(e.message || "An unexpected error occurred during processing.");
      setAppPhase(AppPhase.CONFIGURATION); // Or show error in results phase
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartNew = () => {
    setContentMedia([]);
    setStyleMedia(null);
    setConfig(DEFAULT_CONFIG);
    setResult(null);
    setError(null);
    setAppPhase(AppPhase.CONFIGURATION);
    // Note: Object URLs for previous files are implicitly revoked if new files are uploaded or components unmount,
    // but explicit revocation in remove functions is good practice.
  };
  
  useEffect(() => {
    return () => {
      contentMedia.forEach(mf => URL.revokeObjectURL(mf.previewUrl));
      if (styleMedia) {
        URL.revokeObjectURL(styleMedia.previewUrl);
      }
    };
  }, [contentMedia, styleMedia]);


  return (
    <div className="min-h-screen flex flex-col bg-neutral-dark">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        {appPhase === AppPhase.CONFIGURATION && (
          <div className="space-y-8">
            {!apiKeyAvailable && (
              <div className="bg-yellow-500/20 border border-yellow-600 text-yellow-300 px-4 py-3 rounded-md" role="alert">
                <p className="font-bold">API Key Missing</p>
                <p className="text-sm">{API_KEY_INFO_MESSAGE}</p>
              </div>
            )}
            {error && (
              <div className="bg-red-500/20 border border-red-600 text-red-300 px-4 py-3 rounded-md" role="alert">
                <p className="font-bold">Error</p>
                <p className="text-sm">{error}</p>
              </div>
            )}
            <section className="grid md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-2xl font-semibold text-neutral-light mb-4">1. Upload Content Media</h2>
                <FileUploader
                  onFileSelect={handleContentMediaChange}
                  accept="video/*,image/*"
                  multiple={true}
                  label="Select Content Videos/Images"
                  disabled={contentMedia.length >= MAX_CONTENT_VIDEOS || !apiKeyAvailable}
                />
                {contentMedia.length > 0 && <MediaPreview mediaFiles={contentMedia} onRemove={removeContentMedia} title="Content Media Previews" />}
                 <p className="text-sm text-gray-400 mt-2">Up to {MAX_CONTENT_VIDEOS} content files.</p>
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-neutral-light mb-4">2. Upload Style Medium</h2>
                <FileUploader
                  onFileSelect={handleStyleMediaChange}
                  accept="video/*,image/*"
                  multiple={false}
                  label="Select Style Video/Image"
                  disabled={!!styleMedia || !apiKeyAvailable}
                />
                {styleMedia && <MediaPreview mediaFiles={[styleMedia]} onRemove={removeStyleMedia} title="Style Medium Preview" />}
              </div>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-neutral-light mb-4">3. Configure Parameters</h2>
              <ConfigurationPanel config={config} onConfigChange={handleConfigChange} baseModels={BASE_MODELS} disabled={!apiKeyAvailable} />
            </section>

            <div className="text-center mt-12">
              <button
                onClick={handleStartFineTuning}
                disabled={isLoading || contentMedia.length === 0 || !styleMedia || !apiKeyAvailable}
                className="bg-brand-primary hover:bg-brand-primary/80 text-white font-bold py-3 px-8 rounded-lg text-lg shadow-lg transition-colors duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center mx-auto"
              >
                <SparklesIcon className="w-5 h-5 mr-2" />
                Simulate Style Weaving
              </button>
            </div>
          </div>
        )}

        {appPhase === AppPhase.PROCESSING && (
          <div className="flex flex-col items-center justify-center h-64">
            <LoadingSpinner />
            <p className="text-xl text-neutral-light mt-4">Weaving artistic styles... please wait.</p>
            <p className="text-sm text-gray-400 mt-1">This is a simulation and may take a moment.</p>
          </div>
        )}

        {appPhase === AppPhase.RESULTS && result && (
          <ResultDisplay result={result} onStartNew={handleStartNew} />
        )}
         {appPhase === AppPhase.RESULTS && error && (
            <div className="mt-8 p-6 bg-red-900/50 border border-red-700 rounded-lg shadow-xl text-center">
                <h2 className="text-2xl font-bold text-red-300 mb-4">Processing Failed</h2>
                <p className="text-red-200 mb-6">{error}</p>
                <button
                    onClick={handleStartNew}
                    className="bg-gray-600 hover:bg-gray-500 text-white font-semibold py-2 px-6 rounded-lg transition-colors"
                >
                    Try Again
                </button>
            </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;
    