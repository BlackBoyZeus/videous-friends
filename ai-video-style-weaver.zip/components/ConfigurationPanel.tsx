
import React from 'react';
import { FineTuneConfig } from '../types';

interface ConfigurationPanelProps {
  config: FineTuneConfig;
  onConfigChange: (newConfig: Partial<FineTuneConfig>) => void;
  baseModels: string[];
  disabled?: boolean;
}

const ConfigurationPanel: React.FC<ConfigurationPanelProps> = ({ config, onConfigChange, baseModels, disabled = false }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    onConfigChange({
      [name]: type === 'number' ? parseFloat(value) : value,
    });
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onConfigChange({
      [name]: parseFloat(value),
    });
  };

  return (
    <div className={`p-6 bg-neutral-medium rounded-lg shadow-xl space-y-6 ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}>
      <div>
        <label htmlFor="baseModel" className="block text-sm font-medium text-gray-300 mb-1">Base Model</label>
        <select
          id="baseModel"
          name="baseModel"
          value={config.baseModel}
          onChange={handleInputChange}
          disabled={disabled}
          className="w-full bg-gray-700 border border-gray-600 text-neutral-light rounded-md p-2 focus:ring-brand-primary focus:border-brand-primary"
        >
          {baseModels.map(model => (
            <option key={model} value={model}>{model}</option>
          ))}
        </select>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div>
          <label htmlFor="learningRate" className="block text-sm font-medium text-gray-300 mb-1">Learning Rate</label>
          <input
            type="number"
            id="learningRate"
            name="learningRate"
            value={config.learningRate}
            onChange={handleInputChange}
            step="0.0001"
            min="0.0001"
            max="0.1"
            disabled={disabled}
            className="w-full bg-gray-700 border border-gray-600 text-neutral-light rounded-md p-2 focus:ring-brand-primary focus:border-brand-primary"
          />
        </div>
        <div>
          <label htmlFor="epochs" className="block text-sm font-medium text-gray-300 mb-1">Epochs</label>
          <input
            type="number"
            id="epochs"
            name="epochs"
            value={config.epochs}
            onChange={handleInputChange}
            step="10"
            min="10"
            max="1000"
            disabled={disabled}
            className="w-full bg-gray-700 border border-gray-600 text-neutral-light rounded-md p-2 focus:ring-brand-primary focus:border-brand-primary"
          />
        </div>
        <div>
          <label htmlFor="styleWeight" className="block text-sm font-medium text-gray-300 mb-1">
            Style Weight: <span className="font-bold text-brand-primary">{config.styleWeight.toFixed(2)}</span>
          </label>
          <input
            type="range"
            id="styleWeight"
            name="styleWeight"
            value={config.styleWeight}
            onChange={handleSliderChange}
            min="0.05"
            max="1.0"
            step="0.01"
            disabled={disabled}
            className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-brand-primary disabled:opacity-50"
          />
        </div>
      </div>
      <p className="text-xs text-gray-400">Adjust these parameters to simulate different fine-tuning scenarios.</p>
    </div>
  );
};

export default ConfigurationPanel;
    