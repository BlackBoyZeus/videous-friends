
import React, { useRef } from 'react';
import { IconProps } from '../types';

interface FileUploaderProps {
  onFileSelect: (files: FileList | null) => void;
  accept: string;
  multiple?: boolean;
  label: string;
  disabled?: boolean;
}

const UploadIcon: React.FC<IconProps> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
  </svg>
);

const FileUploader: React.FC<FileUploaderProps> = ({ onFileSelect, accept, multiple = false, label, disabled = false }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onFileSelect(event.target.files);
    // Reset the input value to allow uploading the same file again if needed
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={`border-2 border-dashed border-gray-600 rounded-lg p-6 text-center transition-colors ${disabled ? 'bg-gray-700/50 cursor-not-allowed' : 'hover:border-brand-primary cursor-pointer bg-gray-800/50'}`}
      onClick={!disabled ? handleClick : undefined}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept={accept}
        multiple={multiple}
        className="hidden"
        disabled={disabled}
      />
      <UploadIcon className={`mx-auto mb-3 w-12 h-12 ${disabled ? 'text-gray-500' : 'text-brand-primary'}`} />
      <p className={`text-lg font-semibold ${disabled ? 'text-gray-500' : 'text-neutral-light'}`}>{label}</p>
      <p className={`text-sm ${disabled ? 'text-gray-600' : 'text-gray-400'}`}>Drag & drop or click to browse</p>
      {multiple && <p className={`text-xs ${disabled ? 'text-gray-600' : 'text-gray-500'} mt-1`}>Select multiple files</p>}
    </div>
  );
};

export default FileUploader;
    