
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-medium mt-12 py-6 text-center">
      <p className="text-sm text-gray-400">
        &copy; {new Date().getFullYear()} AI Video Style Weaver. Simulation purposes only.
      </p>
    </footer>
  );
};

export default Footer;
    