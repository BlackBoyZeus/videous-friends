
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-neutral-medium shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-secondary">
          AI Video Style Weaver
        </h1>
        <p className="text-sm text-gray-300 mt-1">Craft unique visual styles for your videos through simulated fine-tuning.</p>
      </div>
    </header>
  );
};

export default Header;
    