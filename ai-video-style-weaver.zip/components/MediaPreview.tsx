
import React from 'react';
import { MediaFile, IconProps } from '../types';

const XCircleIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);


interface MediaPreviewProps {
  mediaFiles: MediaFile[];
  onRemove: (id: string) => void;
  title: string;
}

const MediaPreview: React.FC<MediaPreviewProps> = ({ mediaFiles, onRemove, title }) => {
  if (mediaFiles.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="text-lg font-medium text-neutral-light mb-3">{title}</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {mediaFiles.map((media) => (
          <div key={media.id} className="relative group bg-neutral-medium p-2 rounded-lg shadow">
            {media.file.type.startsWith('image/') ? (
              <img src={media.previewUrl} alt={media.name} className="w-full h-32 object-cover rounded" />
            ) : (
              <video src={media.previewUrl} controls className="w-full h-32 object-cover rounded" />
            )}
            <p className="text-xs text-gray-300 mt-1 truncate" title={media.name}>{media.name}</p>
            <button
              onClick={() => onRemove(media.id)}
              className="absolute top-1 right-1 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 opacity-75 group-hover:opacity-100 transition-opacity"
              aria-label="Remove media"
            >
              <XCircleIcon className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MediaPreview;
    