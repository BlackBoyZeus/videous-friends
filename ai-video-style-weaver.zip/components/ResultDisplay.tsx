
import React from 'react';
import { FineTuneResult, IconProps } from '../types';

const DownloadIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
  </svg>
);

const ArrowPathIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
</svg>
);


interface ResultDisplayProps {
  result: FineTuneResult;
  onStartNew: () => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, onStartNew }) => {
  const handleDownloadModelConfig = () => {
    const modelData = {
      fineTuningConfiguration: result.configSummary,
      aiGeneratedDescription: result.geminiDescription,
      timestamp: result.timestamp,
      appName: "AI Video Style Weaver Simulation",
    };
    const jsonString = JSON.stringify(modelData, null, 2);
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ai_style_weaver_config_${new Date(result.timestamp).toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="mt-8 p-6 md:p-8 bg-neutral-medium rounded-lg shadow-2xl animate-fadeIn">
      <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-500 mb-6 text-center">
        Style Weaving Simulation Complete!
      </h2>
      
      <div className="mb-6 p-4 bg-gray-700/50 rounded-md">
        <h3 className="text-xl font-semibold text-neutral-light mb-2">AI Generated Style Description:</h3>
        <p className="text-gray-300 whitespace-pre-wrap leading-relaxed">
          {result.geminiDescription || "No description generated."}
        </p>
      </div>

      <div className="mb-8 p-4 bg-gray-700/50 rounded-md">
        <h3 className="text-xl font-semibold text-neutral-light mb-3">Configuration Used:</h3>
        <ul className="list-disc list-inside text-gray-300 space-y-1">
          <li><strong>Base Model:</strong> {result.configSummary.baseModel}</li>
          <li><strong>Learning Rate:</strong> {result.configSummary.learningRate}</li>
          <li><strong>Epochs:</strong> {result.configSummary.epochs}</li>
          <li><strong>Style Weight:</strong> {result.configSummary.styleWeight.toFixed(2)}</li>
        </ul>
        <p className="text-xs text-gray-400 mt-3">Simulation Timestamp: {new Date(result.timestamp).toLocaleString()}</p>
      </div>

      <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
        <button
          onClick={handleDownloadModelConfig}
          className="w-full sm:w-auto bg-brand-secondary hover:bg-brand-secondary/80 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-150 ease-in-out flex items-center justify-center"
        >
          <DownloadIcon className="mr-2" />
          Download Simulated Model Config
        </button>
        <button
          onClick={onStartNew}
          className="w-full sm:w-auto bg-gray-600 hover:bg-gray-500 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-150 ease-in-out flex items-center justify-center"
        >
          <ArrowPathIcon className="mr-2" />
          Start New Simulation
        </button>
      </div>
    </div>
  );
};

export default ResultDisplay;
    