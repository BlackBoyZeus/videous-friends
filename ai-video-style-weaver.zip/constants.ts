
import { FineTuneConfig } from './types';

export const BASE_MODELS: string[] = [
  "Artistic Style Transfer Model Alpha",
  "Photorealistic Style Model Beta",
  "Animation Style Model Gamma",
  "Abstract Expressionist Model Delta"
];

export const DEFAULT_CONFIG: FineTuneConfig = {
  baseModel: BASE_MODELS[0],
  learningRate: 0.001,
  epochs: 100,
  styleWeight: 0.75
};

export const MAX_CONTENT_VIDEOS = 5;
export const MAX_FILE_SIZE_MB = 100; // For display purposes, actual upload might be larger
export const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

export const API_KEY_INFO_MESSAGE = "Ensure your Gemini API Key is configured in the environment as API_KEY.";

// Placeholder for API Key if process.env is not polyfilled/available in browser
// In a real build setup, process.env.API_KEY would be replaced.
// For this environment, we assume it might be globally available or needs to be manually set for testing.
export const getApiKey = (): string | undefined => {
  // Attempt to access it via window.process.env for browser environments
  // where 'process' might not be directly available but 'window.process' is.
  // This is a common pattern for environments that don't fully polyfill 'process'.
  if (typeof window !== 'undefined' && (window as any).process && (window as any).process.env && (window as any).process.env.API_KEY) {
    return (window as any).process.env.API_KEY;
  }
  // Fallback for standard Node.js like 'process.env' access, though less likely in browser
  if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
    return process.env.API_KEY;
  }
  // If you are running this in an environment where neither is set,
  // you might need to hardcode it here for development, but this is NOT recommended for production.
  // e.g. return "YOUR_API_KEY_HERE_FOR_LOCAL_DEV_ONLY"; 
  return undefined; 
};
    