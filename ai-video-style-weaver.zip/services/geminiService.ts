
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { FineTuneConfig } from '../types';
import { getApiKey } from '../constants';

// IMPORTANT: This service assumes that `process.env.API_KEY` (or a similar mechanism like window.process.env.API_KEY)
// is available in the execution environment. If it's not (e.g., in a pure static deployment without a build step
// that injects environment variables), the API calls will fail.
// The `getApiKey()` function in constants.ts tries to retrieve it.

let ai: GoogleGenAI | null = null;

const initializeAi = (): GoogleGenAI => {
  if (ai) return ai;
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("Gemini API Key is not configured. Please set API_KEY in your environment.");
  }
  ai = new GoogleGenAI({ apiKey });
  return ai;
};

export const generateStyleDescription = async (
  contentMediaDescription: string,
  styleMediaDescription: string,
  config: FineTuneConfig
): Promise<string> => {
  try {
    const genAI = initializeAi();
    
    const prompt = `
      You are an AI creative assistant specialized in video style transfer.
      A user is simulating fine-tuning a neural style transfer model.
      Their goal is to apply an artistic style from a style medium to content media.

      Content Media Description: ${contentMediaDescription}
      Style Medium Description: ${styleMediaDescription}

      Simulated Fine-Tuning Parameters:
      - Base Model: ${config.baseModel}
      - Learning Rate: ${config.learningRate}
      - Epochs: ${config.epochs}
      - Style Weight: ${config.styleWeight.toFixed(2)}

      Based on all this information, describe the potential visual characteristics of the resulting stylized videos.
      Focus on aspects like:
      - Color palette and transformations
      - Texture application and changes (e.g., brush strokes, patterns)
      - How motion might be affected or appear with the new style
      - The overall artistic impression and mood
      - Any unique interactions between the content and the style
      
      Be descriptive and imaginative. Aim for a paragraph or two.
      Do not repeat the input parameters in your description unless it's natural to the flow.
      Start your description directly. For example: "The resulting videos would likely exhibit..."
    `;

    const response: GenerateContentResponse = await genAI.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", // Use the appropriate model
      contents: prompt,
      // No thinkingConfig, default is fine for this creative task.
    });

    const text = response.text;
    if (!text) {
      throw new Error("Gemini API returned an empty response.");
    }
    return text;

  } catch (error: any) {
    console.error("Error calling Gemini API:", error);
    if (error.message && error.message.includes('API key not valid')) {
        throw new Error("Gemini API Key is invalid. Please check your API_KEY configuration.");
    }
    throw new Error(`Failed to generate style description from Gemini API: ${error.message}`);
  }
};
    