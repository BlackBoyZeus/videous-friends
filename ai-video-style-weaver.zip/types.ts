
export interface MediaFile {
  id: string;
  file: File;
  previewUrl: string;
  name: string;
}

export interface FineTuneConfig {
  baseModel: string;
  learningRate: number;
  epochs: number;
  styleWeight: number; // 0.0 to 1.0
}

export interface FineTuneResult {
  configSummary: FineTuneConfig;
  geminiDescription: string;
  timestamp: string;
}

export enum AppPhase {
  CONFIGURATION,
  PROCESSING,
  RESULTS
}

export interface IconProps {
  className?: string;
}
    