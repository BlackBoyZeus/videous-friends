
import React, { useState, useCallback, useEffect } from 'react';
import { AudioFile, VideoFile, AnalysisConfig, RenderConfig, StoryboardSegment, AppTheme, SequencingMode, AudioDetailsType, VideoFileWithDetails } from './types';
import { DEFAULT_ANALYSIS_CONFIG, DEFAULT_RENDER_CONFIG, APP_THEME } from './constants';
import Header from './components/Header';
import Footer from './components/Footer';
import FileUpload from './components/FileUpload';
import ConfigPanel from './components/ConfigPanel';
import StoryboardViewer from './components/StoryboardViewer';
import { generateStoryboardWithGemini } from './services/geminiService';
import { extractFileMetadata } from './services/mediaService';
import AudioDetailsEditor from './components/AudioDetailsEditor';
import VideoListEditor from './components/VideoListEditor';
import { LoadingIcon } from './components/Icons';

const App: React.FC = () => {
  const [masterAudio, setMasterAudio] = useState<AudioFile | null>(null);
  const [audioDetails, setAudioDetails] = useState<AudioDetailsType | null>(null);
  
  const [videoFiles, setVideoFiles] = useState<VideoFileWithDetails[]>([]);
  
  const [analysisConfig, setAnalysisConfig] = useState<AnalysisConfig>(DEFAULT_ANALYSIS_CONFIG);
  const [renderConfig, setRenderConfig] = useState<RenderConfig>(DEFAULT_RENDER_CONFIG);
  const [sequencingMode, setSequencingMode] = useState<SequencingMode>(SequencingMode.GreedyHeuristic);
  
  const [generatedStoryboard, setGeneratedStoryboard] = useState<StoryboardSegment[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const theme = APP_THEME;

  const handleMasterAudioUpload = async (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      const metadata = await extractFileMetadata(file) as { duration: number };
      setMasterAudio({ file, duration: metadata.duration });
      setAudioDetails({ duration: metadata.duration, mood: '', tempo: '', energy: '', description: '' });
      setGeneratedStoryboard(null);
      setError(null);
    }
  };

  const handleVideoFilesUpload = async (files: FileList) => {
    const newVideoFiles: VideoFileWithDetails[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const metadata = await extractFileMetadata(file) as { duration: number };
      newVideoFiles.push({ 
        id: `${file.name}-${Date.now()}`,
        file, 
        duration: metadata.duration,
        tags: [],
        motion: 'medium',
        brightness: 'medium',
        facePresence: 'medium',
        description: ''
      });
    }
    setVideoFiles(prev => [...prev, ...newVideoFiles]);
    setGeneratedStoryboard(null);
    setError(null);
  };

  const handleCompose = useCallback(async () => {
    if (!masterAudio || !audioDetails || videoFiles.length === 0) {
      setError("Please upload a master audio track, provide its details, and at least one video clip.");
      return;
    }
    if (!process.env.API_KEY) {
      setError("Gemini API Key is missing. Please ensure it's configured in your environment (process.env.API_KEY).");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedStoryboard(null);

    try {
      const storyboard = await generateStoryboardWithGemini(
        masterAudio,
        audioDetails,
        videoFiles,
        analysisConfig,
        renderConfig,
        sequencingMode
      );
      setGeneratedStoryboard(storyboard);
    } catch (e) {
      console.error("Error generating storyboard:", e);
      setError(e instanceof Error ? e.message : "An unknown error occurred while generating the storyboard.");
    } finally {
      setIsLoading(false);
    }
  }, [masterAudio, audioDetails, videoFiles, analysisConfig, renderConfig, sequencingMode]);

  useEffect(() => {
    // This effect is just to log if API_KEY is available for debugging.
    // In a real build, this would be handled by the build process or environment.
    if (!process.env.API_KEY) {
      console.warn("Gemini API Key (process.env.API_KEY) is not set. API calls will fail.");
    }
  }, []);

  return (
    <div className={`min-h-screen flex flex-col ${theme.bg} ${theme.textPrimary}`}>
      <Header theme={theme} />
      <main className="flex-grow container mx-auto p-4 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column: Inputs */}
          <div className="space-y-6">
            <div className={`p-6 rounded-lg shadow-xl ${theme.cardBg} border ${theme.border}`}>
              <h2 className={`text-2xl font-semibold mb-4 ${theme.textAccent}`}>1. Master Audio Track</h2>
              <FileUpload 
                onFileUpload={handleMasterAudioUpload} 
                label="Upload Master Audio (MP3, WAV, etc.)" 
                accept="audio/*" 
                theme={theme}
              />
              {masterAudio && audioDetails && (
                <AudioDetailsEditor audioDetails={audioDetails} setAudioDetails={setAudioDetails} theme={theme} />
              )}
            </div>

            <div className={`p-6 rounded-lg shadow-xl ${theme.cardBg} border ${theme.border}`}>
              <h2 className={`text-2xl font-semibold mb-4 ${theme.textAccent}`}>2. Source Video Clips</h2>
              <FileUpload 
                onFileUpload={handleVideoFilesUpload} 
                label="Upload Video Clips (MP4, MOV, etc.)" 
                accept="video/*" 
                multiple 
                theme={theme}
              />
              {videoFiles.length > 0 && (
                <VideoListEditor videoFiles={videoFiles} setVideoFiles={setVideoFiles} theme={theme} />
              )}
            </div>
          </div>

          {/* Right Column: Config */}
          <div className={`p-6 rounded-lg shadow-xl ${theme.cardBg} border ${theme.border}`}>
            <h2 className={`text-2xl font-semibold mb-4 ${theme.textAccent}`}>3. Remix Configuration</h2>
            <ConfigPanel
              analysisConfig={analysisConfig}
              onAnalysisConfigChange={setAnalysisConfig}
              renderConfig={renderConfig}
              onRenderConfigChange={setRenderConfig}
              sequencingMode={sequencingMode}
              onSequencingModeChange={setSequencingMode}
              theme={theme}
            />
          </div>
        </div>
        
        <div className="text-center">
          <button
            onClick={handleCompose}
            disabled={isLoading || !masterAudio || videoFiles.length === 0 || !audioDetails}
            className={`px-8 py-3 text-lg font-semibold rounded-lg shadow-md transition-all duration-300 ease-in-out 
                        ${theme.buttonPrimaryBg} ${theme.buttonPrimaryText} 
                        hover:${theme.buttonPrimaryHoverBg} 
                        focus:outline-none focus:ring-2 focus:${theme.focusRing} focus:ring-opacity-50
                        disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-600`}
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <LoadingIcon className={`animate-spin h-5 w-5 mr-3 ${theme.textPrimary}`} />
                Chef is Cooking...
              </div>
            ) : (
              "4. Compose Video Remix Plan"
            )}
          </button>
        </div>

        {error && (
          <div className={`mt-4 p-4 rounded-md ${theme.errorBg} ${theme.errorText} border ${theme.errorBorder}`}>
            <h3 className="font-bold">Error:</h3>
            <p>{error}</p>
          </div>
        )}

        {generatedStoryboard && !isLoading && (
          <div className={`mt-6 p-6 rounded-lg shadow-xl ${theme.cardBg} border ${theme.border}`}>
            <h2 className={`text-2xl font-semibold mb-4 ${theme.textAccent}`}>5. Generated Storyboard</h2>
            <StoryboardViewer storyboard={generatedStoryboard} theme={theme} />
          </div>
        )}
      </main>
      <Footer theme={theme} />
    </div>
  );
};

export default App;
