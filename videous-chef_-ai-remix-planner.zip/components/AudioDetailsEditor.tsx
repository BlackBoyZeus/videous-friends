
import React from 'react';
import { AudioDetailsType, AppTheme } from '../types';

interface AudioDetailsEditorProps {
  audioDetails: AudioDetailsType;
  setAudioDetails: React.Dispatch<React.SetStateAction<AudioDetailsType | null>>;
  theme: AppTheme;
}

const InputField: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  theme: AppTheme;
  placeholder?: string;
  textarea?: boolean;
}> = ({ label, value, onChange, theme, placeholder, textarea }) => (
  <div className="mb-3">
    <label className={`block text-sm font-medium ${theme.textSecondary}`}>{label}</label>
    {textarea ? (
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={2}
        className={`mt-1 block w-full shadow-sm sm:text-sm rounded-md p-2
                    ${theme.inputBg} ${theme.border} ${theme.textPrimary}
                    focus:outline-none focus:${theme.focusRing} focus:border-${theme.textAccent.replace('text-','')}`}
      />
    ) : (
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`mt-1 block w-full shadow-sm sm:text-sm rounded-md p-2
                    ${theme.inputBg} ${theme.border} ${theme.textPrimary}
                    focus:outline-none focus:${theme.focusRing} focus:border-${theme.textAccent.replace('text-','')}`}
      />
    )}
  </div>
);


const AudioDetailsEditor: React.FC<AudioDetailsEditorProps> = ({ audioDetails, setAudioDetails, theme }) => {
  const handleChange = (field: keyof AudioDetailsType, value: string) => {
    setAudioDetails(prev => prev ? { ...prev, [field]: value } : null);
  };

  return (
    <div className={`mt-4 p-4 border-t ${theme.border}`}>
      <h4 className={`text-md font-semibold mb-2 ${theme.textPrimary}`}>Describe Master Audio:</h4>
      <p className={`text-xs ${theme.textSecondary} mb-3`}>Duration: {audioDetails.duration.toFixed(1)}s (auto-detected)</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
        <InputField label="Mood (e.g., Energetic, Calm, Epic)" value={audioDetails.mood} onChange={val => handleChange('mood', val)} theme={theme} placeholder="Describe the mood" />
        <InputField label="Tempo (e.g., 120 BPM, Fast, Slow)" value={audioDetails.tempo} onChange={val => handleChange('tempo', val)} theme={theme} placeholder="Estimate tempo/pace" />
        <InputField label="Energy (e.g., High, Medium, Low)" value={audioDetails.energy} onChange={val => handleChange('energy', val)} theme={theme} placeholder="Overall energy level" />
      </div>
      <InputField label="General Description/Notes" value={audioDetails.description} onChange={val => handleChange('description', val)} theme={theme} placeholder="Any other notes for the AI" textarea />
    </div>
  );
};

export default AudioDetailsEditor;
