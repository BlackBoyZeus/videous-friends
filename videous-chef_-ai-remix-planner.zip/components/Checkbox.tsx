
import React from 'react';
import { AppTheme } from '../types';

interface CheckboxProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  theme: AppTheme;
  description?: string;
}

const Checkbox: React.FC<CheckboxProps> = ({ label, checked, onChange, theme, description }) => {
  const id = `checkbox-${label.replace(/\s+/g, '-').toLowerCase()}`;
  return (
    <div className="flex items-start">
      <div className="flex items-center h-5">
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          className={`focus:${theme.focusRing} h-4 w-4 ${theme.textAccent.replace('text-','border-')} rounded cursor-pointer ${theme.inputBg} border-${theme.border} checked:${theme.buttonPrimaryBg} checked:border-transparent`}
        />
      </div>
      <div className="ml-3 text-sm">
        <label htmlFor={id} className={`font-medium ${theme.textPrimary} cursor-pointer`}>{label}</label>
        {description && <p className={`${theme.textSecondary} text-xs`}>{description}</p>}
      </div>
    </div>
  );
};

export default Checkbox;
