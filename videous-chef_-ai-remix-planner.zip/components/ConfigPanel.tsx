
import React, { useState } from 'react';
import { AnalysisConfig, RenderConfig, AppTheme, SequencingMode, EffectParams } from '../types';
import { 
  PACING_PREFERENCE_OPTIONS, 
  VISUAL_COMPLEXITY_OPTIONS, 
  GREEDY_EMPHASIS_OPTIONS, 
  PHYSICS_BALANCE_OPTIONS,
  PREFERRED_TRANSITIONS_OPTIONS,
  EFFECT_INTENSITY_OPTIONS,
  SEQUENCING_MODE_OPTIONS
} from '../constants';
import Slider from './Slider';
import Checkbox from './Checkbox';
import RadioGroup from './RadioGroup';
import Select from './Select'; // Using Select for dropdowns

interface ConfigPanelProps {
  analysisConfig: AnalysisConfig;
  onAnalysisConfigChange: React.Dispatch<React.SetStateAction<AnalysisConfig>>;
  renderConfig: RenderConfig;
  onRenderConfigChange: React.Dispatch<React.SetStateAction<RenderConfig>>;
  sequencingMode: SequencingMode;
  onSequencingModeChange: React.Dispatch<React.SetStateAction<SequencingMode>>;
  theme: AppTheme;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({
  analysisConfig, onAnalysisConfigChange,
  renderConfig, onRenderConfigChange,
  sequencingMode, onSequencingModeChange,
  theme
}) => {
  const [activeTab, setActiveTab] = useState<'shared' | 'modeSpecific' | 'render'>('shared');

  const handleAnalysisChange = <K extends keyof AnalysisConfig,>(key: K, value: AnalysisConfig[K]) => {
    onAnalysisConfigChange(prev => ({ ...prev, [key]: value }));
  };

  const handleRenderChange = <K extends keyof RenderConfig,>(key: K, value: RenderConfig[K]) => {
    onRenderConfigChange(prev => ({ ...prev, [key]: value }));
  };
  
  const tabs = [
    { id: 'shared', label: 'Shared Analysis' },
    { id: 'modeSpecific', label: 'Sequencing Mode Specifics' },
    { id: 'render', label: 'Render Output (Conceptual)' },
  ];

  return (
    <div className="space-y-4">
      <div>
        <div className={`mb-4 border-b ${theme.border}`}>
          <nav className="-mb-px flex space-x-4" aria-label="Tabs">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors
                  ${activeTab === tab.id 
                    ? `${theme.textAccent} border-${theme.textAccent.replace('text-','')}` 
                    : `${theme.textSecondary} border-transparent hover:${theme.textPrimary} hover:border-gray-400`}
                `}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Shared Analysis Tab */}
        {activeTab === 'shared' && (
          <div className="space-y-6 p-2">
            <h3 className={`text-lg font-medium ${theme.textPrimary} mb-2`}>General Clip Constraints</h3>
            <Slider
              label="Min Clip Duration (seconds):"
              min={0.5} max={5} step={0.1}
              value={analysisConfig.minSequenceClipDuration}
              onChange={value => handleAnalysisChange('minSequenceClipDuration', value)}
              theme={theme}
              formatTooltip={val => `${val.toFixed(1)}s`}
            />
            <Slider
              label="Max Clip Duration (seconds):"
              min={1} max={15} step={0.5}
              value={analysisConfig.maxSequenceClipDuration}
              onChange={value => handleAnalysisChange('maxSequenceClipDuration', value)}
              theme={theme}
              formatTooltip={val => `${val.toFixed(1)}s`}
            />
            
            <h3 className={`text-lg font-medium ${theme.textPrimary} mt-4 mb-2`}>Overall Style Preferences</h3>
             <Select
              label="Pacing Preference:"
              options={PACING_PREFERENCE_OPTIONS}
              value={analysisConfig.pacingPreference}
              onChange={value => handleAnalysisChange('pacingPreference', value as AnalysisConfig['pacingPreference'])}
              theme={theme}
            />
            <Select
              label="Visual Complexity:"
              options={VISUAL_COMPLEXITY_OPTIONS}
              value={analysisConfig.visualComplexity}
              onChange={value => handleAnalysisChange('visualComplexity', value as AnalysisConfig['visualComplexity'])}
              theme={theme}
            />
            <Slider
              label="Mood Consistency with Audio (0-1):"
              min={0} max={1} step={0.05}
              value={analysisConfig.moodConsistency}
              onChange={value => handleAnalysisChange('moodConsistency', value)}
              theme={theme}
              formatTooltip={val => val.toFixed(2)}
            />
            <Checkbox
              label="Save Analysis Data (Conceptual)"
              checked={analysisConfig.saveAnalysisData}
              onChange={checked => handleAnalysisChange('saveAnalysisData', checked)}
              theme={theme}
            />
          </div>
        )}

        {/* Mode Specific Tab */}
        {activeTab === 'modeSpecific' && (
          <div className="space-y-6 p-2">
            <h3 className={`text-lg font-medium ${theme.textPrimary} mb-2`}>Sequencing Mode</h3>
            <RadioGroup
              options={SEQUENCING_MODE_OPTIONS}
              selectedValue={sequencingMode}
              onChange={value => onSequencingModeChange(value as SequencingMode)}
              theme={theme}
            />
            
            {sequencingMode === SequencingMode.GreedyHeuristic && (
              <>
                <h4 className={`text-md font-medium ${theme.textSecondary} mt-4 mb-2`}>Greedy Heuristic Emphasis</h4>
                <Select
                  label="Primary Focus:"
                  options={GREEDY_EMPHASIS_OPTIONS}
                  value={analysisConfig.greedyEmphasis}
                  onChange={value => handleAnalysisChange('greedyEmphasis', value as AnalysisConfig['greedyEmphasis'])}
                  theme={theme}
                />
              </>
            )}

            {sequencingMode === SequencingMode.PhysicsParetoMC && (
              <>
                <h4 className={`text-md font-medium ${theme.textSecondary} mt-4 mb-2`}>Balanced Approach Prioritization</h4>
                <Select
                  label="Key Balancing Factor:"
                  options={PHYSICS_BALANCE_OPTIONS}
                  value={analysisConfig.physicsBalance}
                  onChange={value => handleAnalysisChange('physicsBalance', value as AnalysisConfig['physicsBalance'])}
                  theme={theme}
                />
              </>
            )}
          </div>
        )}

        {/* Render Settings Tab */}
        {activeTab === 'render' && (
          <div className="space-y-6 p-2">
            <h3 className={`text-lg font-medium ${theme.textPrimary} mb-2`}>Output Format (Conceptual)</h3>
            <Slider
              label="Target Width (pixels):"
              min={640} max={3840} step={10}
              value={renderConfig.resolutionWidth}
              onChange={value => handleRenderChange('resolutionWidth', value)}
              theme={theme}
              formatTooltip={val => `${val}px`}
            />
            <Slider
              label="Target Height (pixels):"
              min={360} max={2160} step={10}
              value={renderConfig.resolutionHeight}
              onChange={value => handleRenderChange('resolutionHeight', value)}
              theme={theme}
              formatTooltip={val => `${val}px`}
            />
            <Slider
              label="Target FPS:"
              min={24} max={60} step={1}
              value={renderConfig.fps}
              onChange={value => handleRenderChange('fps', value)}
              theme={theme}
              formatTooltip={val => `${val} FPS`}
            />

            <h3 className={`text-lg font-medium ${theme.textPrimary} mt-4 mb-2`}>Transitions & Effects (Conceptual)</h3>
            <label className={`block text-sm font-medium mb-1 ${theme.textSecondary}`}>Preferred Transitions (select multiple):</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PREFERRED_TRANSITIONS_OPTIONS.map(opt => (
                <Checkbox
                  key={opt.value}
                  label={opt.label}
                  checked={renderConfig.preferredTransitions.includes(opt.value)}
                  onChange={checked => {
                    const newTransitions = checked 
                      ? [...renderConfig.preferredTransitions, opt.value]
                      : renderConfig.preferredTransitions.filter(t => t !== opt.value);
                    handleRenderChange('preferredTransitions', newTransitions as Array<EffectParams['type']>);
                  }}
                  theme={theme}
                />
              ))}
            </div>
             <Select
              label="Overall Effect Intensity:"
              options={EFFECT_INTENSITY_OPTIONS}
              value={renderConfig.effectIntensity}
              onChange={value => handleRenderChange('effectIntensity', value as RenderConfig['effectIntensity'])}
              theme={theme}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default ConfigPanel;
