
import React, { useRef } from 'react';
import { AppTheme } from '../types';
import { UploadCloudIcon } from './Icons';

interface FileUploadProps {
  onFileUpload: (files: FileList) => void;
  label: string;
  accept: string;
  multiple?: boolean;
  theme: AppTheme;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload, label, accept, multiple = false, theme }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      onFileUpload(event.target.files);
      // Reset file input to allow re-uploading the same file
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="mb-4">
      <label className={`block text-sm font-medium mb-2 ${theme.textSecondary}`}>{label}</label>
      <div
        onClick={handleClick}
        className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${theme.border} border-dashed rounded-md cursor-pointer hover:${theme.border} hover:bg-opacity-50 transition-colors duration-200 ${theme.inputBg} hover:border-${theme.textAccent.replace('text-','')}`}
      >
        <div className="space-y-1 text-center">
          <UploadCloudIcon className={`mx-auto h-12 w-12 ${theme.textSecondary}`} />
          <div className="flex text-sm text-gray-600">
            <span className={`relative rounded-md font-medium ${theme.textAccent} hover:${theme.textPrimary}`}>
              Click to upload
            </span>
            <input 
              ref={fileInputRef}
              id="file-upload" 
              name="file-upload" 
              type="file" 
              className="sr-only" 
              accept={accept}
              multiple={multiple}
              onChange={handleFileChange}
            />
          </div>
          <p className={`text-xs ${theme.textSecondary}`}>Drag and drop also supported (browser permitting)</p>
        </div>
      </div>
    </div>
  );
};

export default FileUpload;
