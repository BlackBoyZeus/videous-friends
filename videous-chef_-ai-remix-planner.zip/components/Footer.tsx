
import React from 'react';
import { AppTheme } from '../types';

interface FooterProps {
  theme: AppTheme;
}

const Footer: React.FC<FooterProps> = ({ theme }) => {
  return (
    <footer className={`py-4 px-6 text-center ${theme.textSecondary} text-sm border-t ${theme.border} ${theme.cardBg}`}>
      <p>&copy; {new Date().getFullYear()} Videous Chef AI Remix Planner. Conceptual tool for video editing storyboards.</p>
      <p>Powered by React, Tailwind CSS, and the Gemini API.</p>
    </footer>
  );
};

export default Footer;
