
import React from 'react';
import { AppTheme } from '../types';
import { FilmIcon } from './Icons';

interface HeaderProps {
  theme: AppTheme;
}

const Header: React.FC<HeaderProps> = ({ theme }) => {
  return (
    <header className={`${theme.cardBg} shadow-lg py-4 px-6 border-b ${theme.border}`}>
      <div className="container mx-auto flex items-center">
        <FilmIcon className={`h-10 w-10 mr-3 ${theme.textAccent}`} />
        <h1 className={`text-3xl font-bold ${theme.textAccent}`}>
          Videous Chef <span className={`${theme.textPrimary} text-xl font-normal`}>- AI Remix Planner</span>
        </h1>
      </div>
    </header>
  );
};

export default Header;
