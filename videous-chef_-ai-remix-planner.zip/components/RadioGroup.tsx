
import React from 'react';
import { AppTheme } from '../types';

interface RadioOption {
  value: string;
  label: string;
}

interface RadioGroupProps {
  options: RadioOption[];
  selectedValue: string;
  onChange: (value: string) => void;
  theme: AppTheme;
  groupLabel?: string;
}

const RadioGroup: React.FC<RadioGroupProps> = ({ options, selectedValue, onChange, theme, groupLabel }) => {
  const groupName = `radio-group-${groupLabel?.replace(/\s+/g, '-').toLowerCase() || Math.random().toString(36).substring(7)}`;
  return (
    <div>
      {groupLabel && <label className={`block text-sm font-medium mb-2 ${theme.textSecondary}`}>{groupLabel}</label>}
      <div className="space-y-2 sm:space-y-0 sm:flex sm:space-x-4">
        {options.map(option => (
          <div key={option.value} className="flex items-center">
            <input
              id={`${groupName}-${option.value}`}
              name={groupName}
              type="radio"
              value={option.value}
              checked={selectedValue === option.value}
              onChange={(e) => onChange(e.target.value)}
              className={`focus:${theme.focusRing} h-4 w-4 ${theme.textAccent.replace('text-','border-')} border-${theme.border} cursor-pointer checked:${theme.buttonPrimaryBg}`}
            />
            <label htmlFor={`${groupName}-${option.value}`} className={`ml-2 block text-sm font-medium ${theme.textPrimary} cursor-pointer`}>
              {option.label}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RadioGroup;
