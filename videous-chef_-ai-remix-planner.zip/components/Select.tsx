
import React from 'react';
import { AppTheme } from '../types';

interface SelectOption {
  value: string | number;
  label: string;
}

interface SelectProps {
  label: string;
  options: SelectOption[];
  value: string | number;
  onChange: (value: string | number) => void;
  theme: AppTheme;
}

const Select: React.FC<SelectProps> = ({ label, options, value, onChange, theme }) => {
  const id = `select-${label.replace(/\s+/g, '-').toLowerCase()}`;
  return (
    <div>
      <label htmlFor={id} className={`block text-sm font-medium mb-1 ${theme.textSecondary}`}>
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`block w-full pl-3 pr-10 py-2 text-base border rounded-md shadow-sm 
                    focus:outline-none focus:${theme.focusRing} focus:border-${theme.textAccent.replace('text-','')}
                    ${theme.inputBg} ${theme.border} ${theme.textPrimary} sm:text-sm`}
      >
        {options.map(option => (
          <option key={option.value} value={option.value} className={`${theme.cardBg} ${theme.textPrimary}`}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default Select;
