
import React from 'react';
import { AppTheme } from '../types';

interface SliderProps {
  label: string;
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (value: number) => void;
  theme: AppTheme;
  formatTooltip?: (value: number) => string;
}

const Slider: React.FC<SliderProps> = ({ label, min, max, step, value, onChange, theme, formatTooltip }) => {
  const displayValue = formatTooltip ? formatTooltip(value) : value.toFixed(step.toString().split('.')[1]?.length || 0);

  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <label className={`block text-sm font-medium ${theme.textSecondary}`}>{label}</label>
        <span className={`text-sm font-mono px-2 py-0.5 rounded ${theme.inputBg} ${theme.textPrimary}`}>{displayValue}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className={`w-full h-2 rounded-lg appearance-none cursor-pointer 
                    ${theme.inputBg} 
                    [&::-webkit-slider-thumb]:appearance-none 
                    [&::-webkit-slider-thumb]:h-5 
                    [&::-webkit-slider-thumb]:w-5 
                    [&::-webkit-slider-thumb]:rounded-full 
                    [&::-webkit-slider-thumb]:${theme.buttonPrimaryBg} 
                    [&::-webkit-slider-thumb]:shadow-md
                    [&::-webkit-slider-thumb]:transition-all
                    [&::-webkit-slider-thumb]:duration-150
                    [&::-webkit-slider-thumb]:ease-in-out
                    hover:[&::-webkit-slider-thumb]:${theme.buttonPrimaryHoverBg}
                    focus:[&::-webkit-slider-thumb]:ring-2 
                    focus:[&::-webkit-slider-thumb]:${theme.focusRing}
                    focus:[&::-webkit-slider-thumb]:ring-opacity-50

                    [&::-moz-range-thumb]:appearance-none
                    [&::-moz-range-thumb]:h-5 
                    [&::-moz-range-thumb]:w-5 
                    [&::-moz-range-thumb]:rounded-full 
                    [&::-moz-range-thumb]:${theme.buttonPrimaryBg}
                    [&::-moz-range-thumb]:border-none
                    [&::-moz-range-thumb]:shadow-md
                    hover:[&::-moz-range-thumb]:${theme.buttonPrimaryHoverBg}
                    focus:[&::-moz-range-thumb]:ring-2
                    focus:[&::-moz-range-thumb]:${theme.focusRing}
                   `}
      />
    </div>
  );
};

export default Slider;
