
import React from 'react';
import { StoryboardSegment, AppTheme } from '../types';
import { ScissorsIcon, FilmIcon, ZapIcon, CornerDownRightIcon } from './Icons';

interface StoryboardViewerProps {
  storyboard: StoryboardSegment[];
  theme: AppTheme;
}

const StoryboardViewer: React.FC<StoryboardViewerProps> = ({ storyboard, theme }) => {
  if (!storyboard || storyboard.length === 0) {
    return <p className={`${theme.textSecondary}`}>No storyboard generated yet, or the result was empty.</p>;
  }

  return (
    <div className="space-y-4">
      {storyboard.map((segment, index) => (
        <div key={index} className={`p-4 rounded-lg shadow-md ${theme.inputBg} border ${theme.border} transition-all hover:shadow-lg`}>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-2">
            <h3 className={`text-lg font-semibold ${theme.textAccent} flex items-center`}>
              <ScissorsIcon className={`h-5 w-5 mr-2 ${theme.textAccent}`} />
              Segment {index + 1}: {segment.sourceClipName}
            </h3>
            <span className={`text-sm ${theme.textSecondary} mt-1 sm:mt-0`}>
              Duration: {segment.editDurationSeconds.toFixed(1)}s (Source @ {segment.sourceStartTimeSeconds.toFixed(1)}s)
            </span>
          </div>
          
          <p className={`${theme.textPrimary} mb-2 text-sm`}>{segment.description}</p>

          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs items-center mt-2">
            {segment.visualEmphasis && (
              <div className={`flex items-center px-2 py-1 rounded-full ${theme.cardBg} bg-opacity-50`}>
                <FilmIcon className={`h-3 w-3 mr-1 ${theme.textSecondary}`} />
                <span className={theme.textSecondary}>Visual: {segment.visualEmphasis}</span>
              </div>
            )}
            {segment.audioCue && (
              <div className={`flex items-center px-2 py-1 rounded-full ${theme.cardBg} bg-opacity-50`}>
                <ZapIcon className={`h-3 w-3 mr-1 ${theme.textSecondary}`} /> {/* Using Zap as a generic cue icon */}
                <span className={theme.textSecondary}>Audio Cue: {segment.audioCue}</span>
              </div>
            )}
          </div>
          
          {index < storyboard.length - 1 && (
            <div className={`mt-3 pt-2 border-t ${theme.border} border-dashed flex items-center text-sm ${theme.textSecondary}`}>
              <CornerDownRightIcon className={`h-4 w-4 mr-2 transform rotate-90 sm:rotate-0 ${theme.textAccent}`} />
              Transition: <span className={`font-medium ml-1 ${theme.textPrimary}`}>{segment.transitionToNext}</span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default StoryboardViewer;
