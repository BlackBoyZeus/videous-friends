
import React from 'react';
import { VideoFileWithDetails, AppTheme, SimulatedFeatureValue } from '../types';
import { SIMULATED_FEATURE_OPTIONS } from '../constants';
import { Trash2Icon, Edit3Icon } from './Icons'; // Assuming Edit3Icon for tagging

interface VideoListEditorProps {
  videoFiles: VideoFileWithDetails[];
  setVideoFiles: React.Dispatch<React.SetStateAction<VideoFileWithDetails[]>>;
  theme: AppTheme;
}

const VideoListEditor: React.FC<VideoListEditorProps> = ({ videoFiles, setVideoFiles, theme }) => {

  const handleDetailChange = (id: string, field: keyof Omit<VideoFileWithDetails, 'file' | 'duration' | 'id'>, value: string | string[] | SimulatedFeatureValue) => {
    setVideoFiles(prevFiles => 
      prevFiles.map(vf => 
        vf.id === id ? { ...vf, [field]: value } : vf
      )
    );
  };

  const handleRemoveVideo = (id: string) => {
    setVideoFiles(prevFiles => prevFiles.filter(vf => vf.id !== id));
  };

  if (videoFiles.length === 0) return null;

  return (
    <div className="mt-4 space-y-3 max-h-96 overflow-y-auto pr-2">
      <h4 className={`text-md font-semibold mb-2 ${theme.textPrimary}`}>Uploaded Video Clips:</h4>
      {videoFiles.map(video => (
        <div key={video.id} className={`p-3 rounded-md ${theme.inputBg} border ${theme.border}`}>
          <div className="flex justify-between items-center mb-2">
            <span className={`text-sm font-medium ${theme.textPrimary} truncate w-2/3`} title={video.file.name}>
              {video.file.name} ({video.duration.toFixed(1)}s)
            </span>
            <button onClick={() => handleRemoveVideo(video.id)} className={`${theme.buttonSecondaryText} hover:${theme.textPrimary}`}>
              <Trash2Icon className="h-4 w-4" />
            </button>
          </div>
          
          {/* Simplified Detail Editors */}
          <div className="space-y-2 text-xs">
            <div>
              <label className={`block text-xs font-medium ${theme.textSecondary}`}>Description/Content:</label>
              <input 
                type="text"
                value={video.description}
                onChange={e => handleDetailChange(video.id, 'description', e.target.value)}
                placeholder="Briefly describe content (e.g., 'dancing crowd', 'sunset landscape')"
                className={`mt-0.5 block w-full shadow-sm sm:text-xs rounded-md p-1.5 ${theme.cardBg} ${theme.border} ${theme.textPrimary} focus:outline-none focus:${theme.focusRing} focus:border-${theme.textAccent.replace('text-','')}`}
              />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className={`block text-xs font-medium ${theme.textSecondary}`}>Motion:</label>
                <select value={video.motion} onChange={e => handleDetailChange(video.id, 'motion', e.target.value as SimulatedFeatureValue)} className={`mt-0.5 block w-full p-1.5 text-xs rounded-md ${theme.cardBg} ${theme.border} ${theme.textPrimary} focus:${theme.focusRing}`}>
                  {SIMULATED_FEATURE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
              </div>
              <div>
                <label className={`block text-xs font-medium ${theme.textSecondary}`}>Brightness:</label>
                 <select value={video.brightness} onChange={e => handleDetailChange(video.id, 'brightness', e.target.value as SimulatedFeatureValue)} className={`mt-0.5 block w-full p-1.5 text-xs rounded-md ${theme.cardBg} ${theme.border} ${theme.textPrimary} focus:${theme.focusRing}`}>
                  {SIMULATED_FEATURE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
              </div>
              <div>
                <label className={`block text-xs font-medium ${theme.textSecondary}`}>Faces:</label>
                 <select value={video.facePresence} onChange={e => handleDetailChange(video.id, 'facePresence', e.target.value as SimulatedFeatureValue)} className={`mt-0.5 block w-full p-1.5 text-xs rounded-md ${theme.cardBg} ${theme.border} ${theme.textPrimary} focus:${theme.focusRing}`}>
                  {SIMULATED_FEATURE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
              </div>
            </div>
             <div>
              <label className={`block text-xs font-medium ${theme.textSecondary}`}>Tags (comma-separated):</label>
              <input 
                type="text"
                value={video.tags.join(', ')}
                onChange={e => handleDetailChange(video.id, 'tags', e.target.value.split(',').map(tag => tag.trim()).filter(Boolean))}
                placeholder="e.g., outdoor, sunny, energetic"
                className={`mt-0.5 block w-full shadow-sm sm:text-xs rounded-md p-1.5 ${theme.cardBg} ${theme.border} ${theme.textPrimary} focus:outline-none focus:${theme.focusRing} focus:border-${theme.textAccent.replace('text-','')}`}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default VideoListEditor;

