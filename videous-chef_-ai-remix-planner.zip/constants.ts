

import { AnalysisConfig, RenderConfig, AppTheme, SequencingMode, EffectParams } from './types';

export const DEFAULT_ANALYSIS_CONFIG: AnalysisConfig = {
  minSequenceClipDuration: 2, // seconds
  maxSequenceClipDuration: 8, // seconds
  pacingPreference: 'medium',
  visualComplexity: 'moderate',
  moodConsistency: 0.7,
  greedyEmphasis: 'story',
  physicsBalance: 'mood',
  saveAnalysisData: false,
};

export const DEFAULT_RENDER_CONFIG: RenderConfig = {
  resolutionWidth: 1920,
  resolutionHeight: 1080,
  fps: 30,
  preferredTransitions: ['cut', 'fade'],
  effectIntensity: 'medium',
};

export const APP_THEME: AppTheme = {
  bg: 'bg-[#1C2526]', // deep_black
  textPrimary: 'text-[#F5F6F5]', // diamond_white
  textSecondary: 'text-gray-400',
  textAccent: 'text-[#D4AF37]', // gold_accent
  border: 'border-[#2A4B7C]', // jewel_blue
  cardBg: 'bg-[#202B3A]', // Slightly lighter than deep_black, derived from jewel_blue tones
  inputBg: 'bg-[#2A3B50]', // Darker jewel_blue tone for inputs
  buttonPrimaryBg: 'bg-[#2A4B7C]', // jewel_blue
  buttonPrimaryText: 'text-[#F5F6F5]', // diamond_white
  buttonPrimaryHoverBg: 'hover:bg-[#D4AF37]', // gold_accent
  buttonSecondaryBg: 'bg-transparent',
  buttonSecondaryText: 'text-[#D4AF37]',
  buttonSecondaryHoverBg: 'hover:bg-[#D4AF37]/20',
  focusRing: 'ring-[#D4AF37]', // gold_accent
  tabActiveBg: '!bg-[#D4AF37]', // gold_accent
  tabInactiveBg: '!bg-[#2A4B7C]', // jewel_blue
  tabActiveText: '!text-[#1C2526]', // deep_black
  tabInactiveText: '!text-[#F5F6F5]', // diamond_white
  errorBg: 'bg-red-900/50',
  errorText: 'text-red-200',
  errorBorder: 'border-red-700',
};

export const SIMULATED_FEATURE_OPTIONS: Array<{value: 'low' | 'medium' | 'high', label: string}> = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
];

export const PACING_PREFERENCE_OPTIONS: Array<{value: AnalysisConfig['pacingPreference'], label: string}> = [
  { value: 'slow', label: 'Slow Paced' },
  { value: 'medium', label: 'Medium Paced' },
  { value: 'fast', label: 'Fast Paced' },
];

export const VISUAL_COMPLEXITY_OPTIONS: Array<{value: AnalysisConfig['visualComplexity'], label: string}> = [
  { value: 'simple', label: 'Simple Visuals' },
  { value: 'moderate', label: 'Moderate Visuals' },
  { value: 'dynamic', label: 'Dynamic Visuals' },
];

export const GREEDY_EMPHASIS_OPTIONS: Array<{value: AnalysisConfig['greedyEmphasis'], label: string}> = [
  { value: 'action', label: 'Action/Energy' },
  { value: 'emotion', label: 'Emotion/Mood' },
  { value: 'story', label: 'Story/Narrative' },
];

export const PHYSICS_BALANCE_OPTIONS: Array<{value: AnalysisConfig['physicsBalance'], label: string}> = [
  { value: 'rhythm', label: 'Rhythm & Timing' },
  { value: 'mood', label: 'Mood Consistency' },
  { value: 'continuity', label: 'Visual Flow' },
  { value: 'variety', label: 'Scene Variety' },
];

// Fix: Import EffectParams from ./types
export const PREFERRED_TRANSITIONS_OPTIONS: Array<{value: EffectParams['type'], label: string}> = [
  { value: 'cut', label: 'Cut' },
  { value: 'fade', label: 'Fade' },
  { value: 'zoom', label: 'Zoom' },
  { value: 'pan', label: 'Pan' },
  { value: 'wipe', label: 'Wipe' },
];

export const EFFECT_INTENSITY_OPTIONS: Array<{value: RenderConfig['effectIntensity'], label: string}> = [
  { value: 'low', label: 'Subtle' },
  { value: 'medium', label: 'Moderate' },
  { value: 'high', label: 'Strong' },
];

export const SEQUENCING_MODE_OPTIONS: Array<{value: SequencingMode, label: string}> = [
  { value: SequencingMode.GreedyHeuristic, label: 'Greedy Heuristic (Fast, Focused)' },
  { value: SequencingMode.PhysicsParetoMC, label: 'Balanced Approach (Creative, Varied)' },
];