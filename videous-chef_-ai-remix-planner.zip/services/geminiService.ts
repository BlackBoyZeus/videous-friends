
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AudioFile, VideoFileWithDetails, AnalysisConfig, RenderConfig, SequencingMode, StoryboardSegment, AudioDetailsType } from '../types';

let ai: GoogleGenAI | null = null;

const getAIInstance = (): GoogleGenAI => {
  if (!ai) {
    if (!process.env.API_KEY) {
      throw new Error("Gemini API Key is not configured. Set process.env.API_KEY.");
    }
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return ai;
};

function parseGeminiResponse(responseText: string): StoryboardSegment[] {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Matches ```json ... ``` or ``` ... ```
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }

  try {
    const parsedData = JSON.parse(jsonStr);
    // Validate structure
    if (Array.isArray(parsedData) && parsedData.every(item => 
      typeof item.sourceClipName === 'string' &&
      typeof item.sourceStartTimeSeconds === 'number' &&
      typeof item.editDurationSeconds === 'number' &&
      typeof item.transitionToNext === 'string' &&
      typeof item.description === 'string'
    )) {
      return parsedData as StoryboardSegment[];
    }
    throw new Error("Parsed JSON does not match expected StoryboardSegment structure.");
  } catch (e) {
    console.error("Failed to parse JSON response from Gemini:", e);
    console.error("Original response text:", responseText);
    throw new Error(`Failed to parse storyboard from AI response. Please check console for details. Error: ${(e as Error).message}`);
  }
}


export async function generateStoryboardWithGemini(
  masterAudio: AudioFile,
  audioDetails: AudioDetailsType,
  videoFiles: VideoFileWithDetails[],
  analysisConfig: AnalysisConfig,
  renderConfig: RenderConfig,
  sequencingMode: SequencingMode
): Promise<StoryboardSegment[]> {
  
  const aiInstance = getAIInstance();

  let prompt = `You are an expert AI Video Editor. Your task is to create a conceptual storyboard for a music video or remix.
The output MUST be a valid JSON array of storyboard segments. Each segment object MUST conform to this structure:
{
  "sourceClipName": "string", // Filename of the source video clip
  "sourceStartTimeSeconds": number, // Start time in seconds within the original source clip
  "editDurationSeconds": number,   // How long this segment will be in the final edit
  "transitionToNext": "cut" | "fade" | "zoom" | "pan" | "wipe", // Transition to the next segment
  "description": "string", // A brief description of this segment's content or purpose
  "visualEmphasis": "string", // Optional: e.g., "Close-up on singer", "Fast-paced montage"
  "audioCue": "string" // Optional: e.g., "Align cut with drum beat", "Fade video with music fadeout"
}

Master Audio Details:
- Duration: ${audioDetails.duration.toFixed(1)} seconds
- Mood: ${audioDetails.mood || 'Not specified'}
- Tempo: ${audioDetails.tempo || 'Not specified'}
- Energy: ${audioDetails.energy || 'Not specified'}
- Description: ${audioDetails.description || 'N/A'}

Available Video Clips:
${videoFiles.map(vf => 
`- Filename: ${vf.file.name}
  - Duration: ${vf.duration.toFixed(1)}s
  - Description/Content: ${vf.description || 'N/A'}
  - Tags: ${vf.tags.join(', ') || 'N/A'}
  - Simulated Motion: ${vf.motion}
  - Simulated Brightness: ${vf.brightness}
  - Simulated Face Presence: ${vf.facePresence}`
).join('\n')}

Analysis Configuration & Style Preferences:
- Min Clip Duration in Edit: ${analysisConfig.minSequenceClipDuration}s
- Max Clip Duration in Edit: ${analysisConfig.maxSequenceClipDuration}s
- Pacing Preference: ${analysisConfig.pacingPreference}
- Desired Visual Complexity: ${analysisConfig.visualComplexity}
- Mood Consistency with Audio (0=loose, 1=strict): ${analysisConfig.moodConsistency}

Sequencing Mode: ${sequencingMode}
${sequencingMode === SequencingMode.GreedyHeuristic 
  ? `- Greedy Heuristic Emphasis: ${analysisConfig.greedyEmphasis}. This generally means favoring clips that match this emphasis, potentially with faster pacing if emphasis is 'action'.` 
  : `- Balanced Approach Key Factor: ${analysisConfig.physicsBalance}. This means creating a well-rounded edit, paying particular attention to this factor.`
}

Conceptual Render Output Settings (for context, you don't render):
- Resolution: ${renderConfig.resolutionWidth}x${renderConfig.resolutionHeight}
- FPS: ${renderConfig.fps}
- Preferred Transitions: ${renderConfig.preferredTransitions.join(', ')}
- Overall Effect Intensity: ${renderConfig.effectIntensity}

Instructions:
1. Create a sequence of storyboard segments using the available video clips.
2. The total duration of the storyboard (sum of 'editDurationSeconds') should closely match the master audio duration.
3. Ensure each 'editDurationSeconds' respects the Min and Max Clip Duration settings.
4. 'sourceStartTimeSeconds' must be less than the source clip's total duration. 'sourceStartTimeSeconds' + 'editDurationSeconds' should not exceed the source clip's duration.
5. Select appropriate transitions from the allowed types: "cut", "fade", "zoom", "pan", "wipe".
6. Provide a concise 'description' for each segment.
7. Optionally, add 'visualEmphasis' and 'audioCue' for more detail.
8. Adhere strictly to the JSON output format specified above. Do NOT include any explanatory text outside the JSON structure.
   The entire response should be ONLY the JSON array.

Begin JSON Output:
`;

  try {
    const response: GenerateContentResponse = await aiInstance.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", // Correct model
      contents: prompt,
      config: {
        responseMimeType: "application/json", // Request JSON output
        temperature: 0.6, // Moderate temperature for some creativity but still structured
        topP: 0.9,
        topK: 40,
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("Received empty response from Gemini API.");
    }
    return parseGeminiResponse(responseText);

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
        throw new Error("Gemini API Key is invalid. Please check your configuration.");
    }
    // Attempt to get more details from Gemini error if possible
    // const gError = error as GoogleGenerativeAIError; // This type might not exist directly, depends on SDK
    // if (gError && gError.message) {
    //   throw new Error(`Gemini API Error: ${gError.message}`);
    // }
    throw new Error(`Failed to generate storyboard via Gemini API. Error: ${(error as Error).message}`);
  }
}
