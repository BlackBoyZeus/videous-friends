
import { MediaFileMetadata } from '../types';

export const extractFileMetadata = (file: File): Promise<MediaFileMetadata> => {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    let mediaElement: HTMLAudioElement | HTMLVideoElement;

    if (file.type.startsWith('audio/')) {
      mediaElement = document.createElement('audio');
    } else if (file.type.startsWith('video/')) {
      mediaElement = document.createElement('video');
      // For video, we might want to preload metadata to get dimensions, fps etc.
      // However, 'loadedmetadata' event is sufficient for duration.
      // (mediaElement as HTMLVideoElement).preload = 'metadata';
    } else {
      // For unknown types, try with audio element as a fallback for duration
      console.warn(`Unknown file type: ${file.type}. Attempting to get duration as audio.`);
      mediaElement = document.createElement('audio');
      // reject(new Error(`Unsupported file type: ${file.type}`));
      // return;
    }

    mediaElement.onloadedmetadata = () => {
      URL.revokeObjectURL(url); // Clean up object URL
      resolve({
        duration: mediaElement.duration,
      });
    };

    mediaElement.onerror = (e) => {
      URL.revokeObjectURL(url); // Clean up object URL
      console.error("Error loading media metadata:", mediaElement.error, e);
      // Fallback: If metadata fails, resolve with 0 or a specific error
      // This can happen if the browser can't decode the media type for metadata purposes
      // For now, let's resolve with a 0 duration and log a warning.
      // Ideally, you might want to inform the user more directly.
      console.warn(`Could not determine duration for ${file.name}. Using 0s. Browser error: ${mediaElement.error?.message}`);
      resolve({ duration: 0 });
      // reject(new Error(`Error loading media file ${file.name} for metadata extraction.`));
    };

    mediaElement.src = url;
    mediaElement.load(); // Important to trigger loading for some browsers/formats
  });
};
