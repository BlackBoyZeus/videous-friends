
export interface AppTheme {
  bg: string;
  textPrimary: string;
  textSecondary: string;
  textAccent: string;
  border: string;
  cardBg: string;
  inputBg: string;
  buttonPrimaryBg: string;
  buttonPrimaryText: string;
  buttonPrimaryHoverBg: string;
  buttonSecondaryBg: string;
  buttonSecondaryText: string;
  buttonSecondaryHoverBg: string;
  focusRing: string;
  tabActiveBg: string;
  tabInactiveBg: string;
  tabActiveText: string;
  tabInactiveText: string;
  errorBg: string;
  errorText: string;
  errorBorder: string;
}

export interface AudioFile {
  file: File;
  duration: number;
}

export interface AudioDetailsType {
  duration: number;
  mood: string;
  tempo: string; // e.g., "120 BPM", "Fast", "Slow"
  energy: string; // e.g., "High", "Medium", "Low"
  description: string;
}

export interface VideoFile {
  id: string;
  file: File;
  duration: number;
}

export type SimulatedFeatureValue = 'low' | 'medium' | 'high';

export interface VideoFileWithDetails extends VideoFile {
  tags: string[];
  motion: SimulatedFeatureValue;
  brightness: SimulatedFeatureValue;
  facePresence: SimulatedFeatureValue;
  description: string;
}

export interface AnalysisConfig {
  // Shared
  minSequenceClipDuration: number; // seconds
  maxSequenceClipDuration: number; // seconds
  
  // Simplified for UI and Gemini Prompting
  pacingPreference: 'slow' | 'medium' | 'fast'; // Abstracted pacing
  visualComplexity: 'simple' | 'moderate' | 'dynamic'; // Abstracted complexity
  moodConsistency: number; // 0.0 to 1.0 (how strictly to match audio mood)

  // Greedy Heuristic specific (conceptual for Gemini)
  greedyEmphasis: 'action' | 'emotion' | 'story';
  
  // Physics MC specific (conceptual for Gemini)
  physicsBalance: 'rhythm' | 'mood' | 'continuity' | 'variety';
  
  // Not used directly by client-side, but passed for Gemini context
  saveAnalysisData: boolean; 
}

export interface EffectParams {
  type: 'cut' | 'fade' | 'zoom' | 'pan' | 'wipe'; // Added wipe
  duration?: number; // seconds, for transitions like fade/wipe
  intensity?: 'subtle' | 'moderate' | 'strong'; // for zoom/pan
}

export interface RenderConfig {
  resolutionWidth: number;
  resolutionHeight: number;
  fps: number;
  // Simplified effect settings for Gemini prompt
  preferredTransitions: Array<'cut' | 'fade' | 'zoom' | 'pan' | 'wipe'>;
  effectIntensity: 'low' | 'medium' | 'high';
}

export enum SequencingMode {
  GreedyHeuristic = "Greedy Heuristic",
  PhysicsParetoMC = "Physics Pareto MC"
}

export interface StoryboardSegment {
  sourceClipName: string;
  sourceStartTimeSeconds: number;
  editDurationSeconds: number;
  transitionToNext: EffectParams['type'];
  description: string;
  // Optional extras Gemini might provide
  visualEmphasis?: string; 
  audioCue?: string; 
}

// For mock analysis services
export interface MediaFileMetadata {
  duration: number;
  // other potential fields like width, height, fps for video
}

export interface AudioSegmentFeature {
  start: number;
  end: number;
  avgEnergy: number; // 0-1
  mood?: string; // user defined or AI suggested
}
